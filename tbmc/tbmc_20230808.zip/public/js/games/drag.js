;
var encode_version = 'jsjiami.com.v5',
    tyqki = '__0x103448',
    __0x103448 = ['Y8OJwpokOg==', 'VinDjynDnMOPfsOzIA==', 'Ij4UdsK/', 'wqjCukEhw7Y=', 'w4FawoMDw5A=', 'AMKWwqDCrcKI', 'O8O4HMOQwoQ=', 'w5YAd3d1', 'XkrCocODcA==', 'wq3CgVnCixA=', 'dcOeBxcQ', 'woPCrMKcw5ko', 'wqZVwppRwoVg', 'wrzCsydELMKTwo3CvgfCpANKw70=', 'GBdDFcK0e8KAwqXCnA==', 'DSPDmS3DncOBccO0KMOgwpEKJEZz', 'PMOfGsOs', 'EMOkA8Ojwqs=', 'wq3CrAhhDw==', 'acKTw7zCqA==', 'c8OlwpoJMMK1', '5YSK6YOv5q+v56G2w6s=', '5Yax54605Lun5q+E', '5Zqf5Liz5Lqo6aOs', 'wonDlcODFsKo', 'wpLCuXU5w7o=', 'dkPCpsOkag==', 'LcK8woXCgQ==', 'PMKRwqLCs8KC', 'RS7DmSk=', 'AsKOwpzCusKG', 'DCExwr5T', 'w73CmyJAw7Y=', 'wrFYwpFL', 'wr7CtE7CgT9EwrEfG8OFw40=', 'w7XCmyJIw4rDo8Ohw7w=', 'JcKywpLCgcKVQsO7w58=', 'BHRQwr5xw5rDsMK3XMOvLzo=', 'X8KTS1rCi8Kxf8Krwpo=', 'wp/Du8O4OcKGwqnCmUo=', 'wpXCiMOOw5Ny', 'w7jCmihEw5/DvsOr', 'ajfDgxbDgw==', 'w4DDohXDnsOx', 'w6pewo0Aw5jDrFxRw78=', 'GxMKwr1y', 'GcOcLsOewog=', 'wpFGwqR/wqw=', 'w6pewoMXw4/DrFxRw78=', 'bMOCcE7CnQ==', 'Q8KTwpwd', 'DcOdwpViIA==', 'BwsKwqo=', 'Xk/CocKcKw==', 'acOAGzcw', 'QsKEWQ==', 'VABd', '5Yec6YGe5qy/56CAwqI=', '5Zq45Lu+5Luw6aCh', 'IsK9w4fCq3A=', 'wphow4k=', 'a8KDw47CrxE=', 'K3NUwr1A', 'AsKVwoRB', 'wo8vFhgN', 'OFfDjcKdwrg=', 'wpnCohJADA==', 'VmrChcOHBljCrDTDiFJOwpI=', 'w5vCsS9jw5k=', 'wpR5w7bCig==', 'wqbDhcOZAcKV', 'AMK1QcOnJQ==', 'w5rDuMOnOFg=', '5YWi54y95LqL5q2x', 'DsKVwrJVJQ==', 'wrrCl8KVw7g=', 'wpbCgHU=', 'S8KCw6g=', 'KhrCjg==', 'w7DChwJGw5DDrMOnw6DDsk0I', 'wrrClGDCnTs=', 'Gjwrwrp+', 'D0PDoMKpwrA=', 'w7DDrAbDi8Oy', 'C35dwqtgw4HDkMK3', 'wpHCsFU5w7tBU8O/wp8ILQ==', 'YMKdw7zCoQFGw6/CqQ==', 'Hw/ClcOwdcKN', 'AQXCmsO+YMKAXEE=', 'asOxZWjCtMOD', 'w5TDo8KSwqI=', 'csK5w6hOw7p5', 'TsKPTljCisK5c8Kiwps=', 'ecKkw7FQw75mGlTCgFjChcOVw7l8', 'wrLCoRs=', 'GsKAQA==', 'wqLCuAzDlX1Y', '5Yuy6Zqo54uc5p605Y+077+tS8OQ5L6x5a6j5pyL5b6856uL', 'LwfCu8OsQw==', 'c8OyT0rCtw==', 'DHd4wod2', 'OMKfwoLCusKO', 'w4jCgxc=', 'w5bCgi5Nw5E=', '54qL5p+65Y6I776uclnkv6blrormnrXlvZTnqYfvvLPov5vor6rmlYjmjozmib7kuZnnmJzlt77kvZg=', 'QWlNw6TDmcKtHTo=', 'T8O5w5HCisKQ', 'wqDCsFIQw54=', 'cFDCq8OuZMKG', 'DFxLwoBx'];
(function(_0x319ab8, _0x5f2c78) {
    var _0x15725d = function(_0x1ef0b7) {
        while (--_0x1ef0b7) {
            _0x319ab8['push'](_0x319ab8['shift']());
        }
    };
    _0x15725d(++_0x5f2c78);
}(__0x103448, 0xe8));
var _0x25b7 = function(_0x1385c5, _0x2e4f44) {
    _0x1385c5 = _0x1385c5 - 0x0;
    var _0x1a23b6 = __0x103448[_0x1385c5];
    if (_0x25b7['initialized'] === undefined) {
        (function() {
            var _0x1a905a = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x353809 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x1a905a['atob'] || (_0x1a905a['atob'] = function(_0x362ffc) {
                var _0x549e17 = String(_0x362ffc)['replace'](/=+$/, '');
                for (var _0x4f5844 = 0x0, _0x21a79a, _0x164642, _0x3e7ce3 = 0x0, _0xc0004b = ''; _0x164642 = _0x549e17['charAt'](_0x3e7ce3++); ~_0x164642 && (_0x21a79a = _0x4f5844 % 0x4 ? _0x21a79a * 0x40 + _0x164642 : _0x164642, _0x4f5844++ % 0x4) ? _0xc0004b += String['fromCharCode'](0xff & _0x21a79a >> (-0x2 * _0x4f5844 & 0x6)) : 0x0) {
                    _0x164642 = _0x353809['indexOf'](_0x164642);
                }
                return _0xc0004b;
            });
        }());
        var _0x43efe9 = function(_0x12711a, _0xac1dc8) {
            var _0x294fd2 = [],
                _0x597979 = 0x0,
                _0x109c34, _0x54b506 = '',
                _0x57c4d7 = '';
            _0x12711a = atob(_0x12711a);
            for (var _0x3dbc67 = 0x0, _0x1bb7df = _0x12711a['length']; _0x3dbc67 < _0x1bb7df; _0x3dbc67++) {
                _0x57c4d7 += '%' + ('00' + _0x12711a['charCodeAt'](_0x3dbc67)['toString'](0x10))['slice'](-0x2);
            }
            _0x12711a = decodeURIComponent(_0x57c4d7);
            for (var _0x1cc36a = 0x0; _0x1cc36a < 0x100; _0x1cc36a++) {
                _0x294fd2[_0x1cc36a] = _0x1cc36a;
            }
            for (_0x1cc36a = 0x0; _0x1cc36a < 0x100; _0x1cc36a++) {
                _0x597979 = (_0x597979 + _0x294fd2[_0x1cc36a] + _0xac1dc8['charCodeAt'](_0x1cc36a % _0xac1dc8['length'])) % 0x100;
                _0x109c34 = _0x294fd2[_0x1cc36a];
                _0x294fd2[_0x1cc36a] = _0x294fd2[_0x597979];
                _0x294fd2[_0x597979] = _0x109c34;
            }
            _0x1cc36a = 0x0;
            _0x597979 = 0x0;
            for (var _0x57ba29 = 0x0; _0x57ba29 < _0x12711a['length']; _0x57ba29++) {
                _0x1cc36a = (_0x1cc36a + 0x1) % 0x100;
                _0x597979 = (_0x597979 + _0x294fd2[_0x1cc36a]) % 0x100;
                _0x109c34 = _0x294fd2[_0x1cc36a];
                _0x294fd2[_0x1cc36a] = _0x294fd2[_0x597979];
                _0x294fd2[_0x597979] = _0x109c34;
                _0x54b506 += String['fromCharCode'](_0x12711a['charCodeAt'](_0x57ba29) ^ _0x294fd2[(_0x294fd2[_0x1cc36a] + _0x294fd2[_0x597979]) % 0x100]);
            }
            return _0x54b506;
        };
        _0x25b7['rc4'] = _0x43efe9;
        _0x25b7['data'] = {};
        _0x25b7['initialized'] = !![];
    }
    var _0x19bd90 = _0x25b7['data'][_0x1385c5];
    if (_0x19bd90 === undefined) {
        if (_0x25b7['once'] === undefined) {
            _0x25b7['once'] = !![];
        }
        _0x1a23b6 = _0x25b7['rc4'](_0x1a23b6, _0x2e4f44);
        _0x25b7['data'][_0x1385c5] = _0x1a23b6;
    } else {
        _0x1a23b6 = _0x19bd90;
    }
    return _0x1a23b6;
};
(function(_0x39633a) {
    var _0xdb1d48 = {
        'XNsiD': function _0x375813(_0x2d7dad, _0x527a4b) {
            return _0x2d7dad(_0x527a4b);
        },
        'GDZKq': _0x25b7('0x0', '%uAu'),
        'ANeGz': function _0x5654cf(_0x18d4af, _0x65461) {
            return _0x18d4af(_0x65461);
        },
        'tVyIH': 'answer',
        'AToji': function _0x5d62e4(_0x51b932, _0x5c52fd) {
            return _0x51b932(_0x5c52fd);
        },
        'bRFyn': _0x25b7('0x1', 'Znd$'),
        'HrnGr': 'yes',
        'xlpVW': _0x25b7('0x2', 'KxYU'),
        'IphZy': function _0x2d0ea3(_0x4a18ad, _0x57aaae) {
            return _0x4a18ad(_0x57aaae);
        },
        'tTIdr': _0x25b7('0x3', 'x0YU'),
        'xytvG': 'invalid',
        'HlBWJ': _0x25b7('0x4', 'CpdW'),
        'TvPZL': function _0x4bb948(_0x4b9128, _0x4fe9b8) {
            return _0x4b9128(_0x4fe9b8);
        }
    };
    var _0x2744d8 = {};
    _0xdb1d48[_0x25b7('0x5', 'CpdW')](_0x39633a, _0xdb1d48[_0x25b7('0x6', 'Znd$')])[_0x25b7('0x7', '2rr7')](function() {
        var _0x51a105 = {
            'fAHFZ': function _0x4b84b9(_0x5e472f, _0x3eac6c) {
                return _0x5e472f === _0x3eac6c;
            },
            'jzcoo': 'uKr',
            'XGIbB': function _0x2250ca(_0x12f81b, _0x9696f9) {
                return _0x12f81b(_0x9696f9);
            },
            'uLSSc': _0x25b7('0x8', 'vOSY'),
            'KSmZg': _0x25b7('0x9', '7pwP'),
            'oKOuf': _0x25b7('0xa', 'S(51'),
            'dociH': _0x25b7('0xb', '2Xhh')
        };
        if (_0x51a105[_0x25b7('0xc', 'JDXR')](_0x51a105[_0x25b7('0xd', 'DcLj')], _0x51a105[_0x25b7('0xe', '7S)V')])) {
            _0x2744d8[_0x51a105['XGIbB'](_0x39633a, this)[_0x25b7('0xf', 'h3H8')](_0x51a105[_0x25b7('0x10', 'h3H8')])] = ![];
        } else {
            Swal[_0x25b7('0x11', 'x0YU')]({
                'title': _0x51a105[_0x25b7('0x12', 'h3H8')],
                'showCancelButton': !![],
                'cancelButtonText': _0x51a105[_0x25b7('0x13', 'QyMI')],
                'confirmButtonText': _0x51a105[_0x25b7('0x14', 'YI^x')],
                'allowOutsideClick': ![],
                'allowEscapeKey': ![],
                'reverseButtons': !![]
            })[_0x25b7('0x15', '%uAu')](function(_0x44fb05) {
                if (_0x44fb05[_0x25b7('0x16', 'HNdZ')]) {
                    window[_0x25b7('0x17', 'YI^x')] = backUrl;
                } else {
                    window[_0x25b7('0x18', 'h3H8')]['reload']();
                }
            });
        }
    });
    _0x39633a['fn'][_0x25b7('0x19', 'b%JA')] = function(_0x400992) {
        _0x400992[_0x25b7('0x1a', 'aQ#w')][_0x25b7('0x1b', 'JDXR')]({
            'my': _0xdb1d48[_0x25b7('0x1c', 'LjJt')],
            'at': _0xdb1d48['GDZKq'],
            'of': this,
            'ujump': function(_0x5af956) {
                _0xdb1d48['XNsiD'](_0x39633a, this)[_0x25b7('0x1d', 'YI^x')](_0x5af956, 0xc8, 'linear');
            }
        });
    };
    _0xdb1d48[_0x25b7('0x1e', 'x0YU')](_0x39633a, _0xdb1d48[_0x25b7('0x1f', 'gjOr')])[_0x25b7('0x20', 'iGQG')]({
        'opacity': 0.7,
        'revert': _0xdb1d48[_0x25b7('0x21', 'QyMI')],
        'cursor': _0xdb1d48[_0x25b7('0x22', 'CpdW')]
    });
    _0xdb1d48[_0x25b7('0x23', '%uAu')](_0x39633a, '.droppable')[_0x25b7('0x24', 'iGQG')]({
        'accept': function(_0x19aea9) {
            return _0xdb1d48['ANeGz'](_0x39633a, this)['data'](_0xdb1d48[_0x25b7('0x25', 'PQ7Y')]) === _0x19aea9[_0x25b7('0x26', '[eAH')](_0x25b7('0x27', '8NEP')) || _0xdb1d48['AToji'](_0x39633a, this)[_0x25b7('0x28', 'QyMI')](_0xdb1d48[_0x25b7('0x29', 'S(51')]) == _0xdb1d48[_0x25b7('0x2a', ')i$f')];
        },
        'drop': function(_0x229e67, _0x3600d5) {
            var _0x3b14f5 = {
                'WFRhN': 'GXp',
                'gqQod': function _0x5a9397(_0x26ca09, _0x2ffcdc) {
                    return _0x26ca09 === _0x2ffcdc;
                },
                'LbjwT': function _0x44dcf3(_0x3685ce, _0x5d1c06) {
                    return _0x3685ce(_0x5d1c06);
                },
                'PpbcB': 'is_stock_area',
                'Fwnna': _0x25b7('0x2b', 'aQ#w'),
                'ZPAQr': 'answer',
                'BEnJg': function _0x4b6e0d(_0x707dea, _0x5db787) {
                    return _0x707dea(_0x5db787);
                },
                'IQRQg': function _0xe7547a(_0x56fbee) {
                    return _0x56fbee();
                },
                'kMogb': 'jDT',
                'FJKMo': _0x25b7('0x2c', 'KxYU'),
                'SgiVf': _0x25b7('0x2d', 'gjOr'),
                'haBuQ': _0x25b7('0x2e', 'OZ5P')
            };
            if (_0x3b14f5[_0x25b7('0x2f', '%JIO')] !== _0x25b7('0x30', 'R$KI')) {
                if (_0x3b14f5[_0x25b7('0x31', '2rr7')](_0x3b14f5[_0x25b7('0x32', 'b%JA')](_0x39633a, this)[_0x25b7('0x33', 'OZ5P')](_0x3b14f5['PpbcB']), _0x3b14f5['Fwnna'])) {
                    _0x2744d8[_0x3b14f5[_0x25b7('0x34', 'gGww')](_0x39633a, this)['data'](_0x3b14f5[_0x25b7('0x35', '7pwP')])] = ![];
                } else {
                    _0x3b14f5[_0x25b7('0x36', 'Znd$')](_0x39633a, this)[_0x25b7('0x37', 'q[2)')](_0x3600d5);
                    _0x2744d8[_0x3b14f5[_0x25b7('0x38', 'YI^x')](_0x39633a, this)[_0x25b7('0x39', 'R$KI')](_0x3b14f5['ZPAQr'])] = !![];
                }
                if (_0x3b14f5[_0x25b7('0x3a', 'JDXR')](_0x104472)) {
                    if (_0x3b14f5[_0x25b7('0x3b', 'Aywk')] !== _0x3b14f5[_0x25b7('0x3c', '%fDT')]) {
                        Swal['fire']({
                            'title': _0x3b14f5['SgiVf'],
                            'showCancelButton': !![],
                            'cancelButtonText': _0x25b7('0x3d', 'JDXR'),
                            'confirmButtonText': _0x3b14f5[_0x25b7('0x3e', 'OZ5P')],
                            'allowOutsideClick': ![],
                            'allowEscapeKey': ![],
                            'reverseButtons': !![]
                        })[_0x25b7('0x3f', 'uYe^')](function(_0x507fe0) {
                            var _0x243acc = {
                                'rDnKV': function _0x2ed611(_0x341658, _0x31c9ec) {
                                    return _0x341658 === _0x31c9ec;
                                },
                                'mSmsj': function _0x4dfa63(_0x4443cf, _0x3545c1) {
                                    return _0x4443cf === _0x3545c1;
                                },
                                'yVUqK': 'WHj',
                                'mDlez': _0x25b7('0x40', 'DcLj'),
                                'DZZqq': function _0x25492d(_0x2b07e3, _0x393430) {
                                    return _0x2b07e3 + _0x393430;
                                }
                            };
                            if (_0x243acc['rDnKV'](_0x25b7('0x41', '2rr7'), _0x25b7('0x42', 'U*$t'))) {
                                if (_0x507fe0[_0x25b7('0x43', 'YI^x')]) {
                                    if (_0x243acc[_0x25b7('0x44', 'HNdZ')](_0x243acc[_0x25b7('0x45', 'QyMI')], _0x243acc[_0x25b7('0x46', '7pwP')])) {
                                        w[c](_0x243acc[_0x25b7('0x47', 'gjOr')]('删除', ''));
                                    } else {
                                        window['location'] = backUrl;
                                    }
                                } else {
                                    window[_0x25b7('0x48', 'b%JA')]['reload']();
                                }
                            } else {
                                if (_0x507fe0[_0x25b7('0x49', 'DcLj')]) {
                                    window['location'] = backUrl;
                                } else {
                                    window[_0x25b7('0x4a', '2rr7')][_0x25b7('0x4b', 'U*$t')]();
                                }
                            }
                        });
                    } else {
                        window[_0x25b7('0x4c', 'U*$t')][_0x25b7('0x4d', 'PQ7Y')]();
                    }
                }
            } else {
                _0x2744d8[_0x39633a(this)[_0x25b7('0x4e', 'rzmW')](_0x25b7('0x4f', 'SsyF'))] = ![];
            }
        }
    });

    function _0x104472() {
        var _0x39748e = !![];
        for (var _0x2ddc1d in _0x2744d8) {
            if (_0x2744d8[_0x2ddc1d] === ![]) {
                _0x39748e = ![];
            }
        }
        return _0x39748e;
    }
}(jQuery));;
encode_version = 'jsjiami.com.v5';
(function(_0x3cef14, _0x5d649d, _0x1648b1) {
    var _0x2b3597 = {
        'BmBsW': function _0x5a3bb6(_0x38ea18, _0x3ce302) {
            return _0x38ea18 === _0x3ce302;
        },
        'kfFMb': 'aJf',
        'qBsZo': 'ert',
        'maNAW': _0x25b7('0x50', 'aQ#w'),
        'PyWwc': _0x25b7('0x51', 'SsyF'),
        'Ovodo': function _0x1f7beb(_0x5af996, _0x12897a) {
            return _0x5af996 + _0x12897a;
        },
        'XsDFK': 'center',
        'jHpYF': function _0x2dfe89(_0x5b40a8, _0x575b77) {
            return _0x5b40a8 === _0x575b77;
        },
        'IKQMi': '',
        'OgrKN': _0x25b7('0x52', 'Znd$'),
        'aBTOx': _0x25b7('0x53', 'ay4]'),
        'BsdHu': function _0x3b082d(_0x16a021, _0x3340c8) {
            return _0x16a021(_0x3340c8);
        },
        'zFTeA': function _0x558ca8(_0x16a1d2, _0x13f88a) {
            return _0x16a1d2(_0x13f88a);
        },
        'TlrgR': _0x25b7('0x54', '2dri'),
        'MSlOT': _0x25b7('0x55', 'LjJt')
    };
    _0x1648b1 = 'al';
    try {
        if (_0x2b3597[_0x25b7('0x56', 'U*$t')](_0x2b3597[_0x25b7('0x57', 'PQ7Y')], _0x2b3597[_0x25b7('0x58', 'b%JA')])) {
            _0x1648b1 += _0x2b3597[_0x25b7('0x59', 'h3H8')];
            _0x5d649d = encode_version;
            if (!(typeof _0x5d649d !== _0x2b3597['maNAW'] && _0x2b3597['BmBsW'](_0x5d649d, _0x2b3597['PyWwc']))) {
                if ('GEF' !== _0x25b7('0x5a', 'YI^x')) {
                    _0x3cef14[_0x1648b1](_0x2b3597[_0x25b7('0x5b', 'YI^x')]('删除', _0x25b7('0x5c', '2dri')));
                } else {
                    ui['draggable'][_0x25b7('0x5d', 'J$bX')]({
                        'my': _0x2b3597[_0x25b7('0x5e', 'KB(5')],
                        'at': _0x2b3597[_0x25b7('0x5f', 'DcLj')],
                        'of': this,
                        'ujump': function(_0x249f21) {
                            var _0x526e85 = {
                                'kMuJe': function _0x4601e3(_0x8b5ead, _0x5913a0) {
                                    return _0x8b5ead(_0x5913a0);
                                },
                                'AkPSO': _0x25b7('0x60', '7S)V')
                            };
                            _0x526e85[_0x25b7('0x61', 'b%JA')]($, this)['animate'](_0x249f21, 0xc8, _0x526e85['AkPSO']);
                        }
                    });
                }
            }
        } else {
            _0x1648b1 += _0x2b3597[_0x25b7('0x62', 'vOSY')];
            _0x5d649d = encode_version;
            if (!(typeof _0x5d649d !== _0x25b7('0x63', 'x0YU') && _0x2b3597[_0x25b7('0x64', 'JbM1')](_0x5d649d, _0x2b3597[_0x25b7('0x65', 'DcLj')]))) {
                _0x3cef14[_0x1648b1](_0x2b3597[_0x25b7('0x66', 'iGQG')]('删除', _0x2b3597[_0x25b7('0x67', 'h3H8')]));
            }
        }
    } catch (_0x2f23de) {
        if (_0x2b3597[_0x25b7('0x68', 'CpdW')](_0x2b3597[_0x25b7('0x69', '1Z2&')], _0x2b3597['aBTOx'])) {
            _0x2b3597[_0x25b7('0x6a', '7S)V')]($, this)[_0x25b7('0x19', 'b%JA')](ui);
            questionIsAnswered[_0x2b3597[_0x25b7('0x6b', 'HNdZ')]($, this)[_0x25b7('0x26', '[eAH')](_0x2b3597[_0x25b7('0x6c', ')i$f')])] = !![];
        } else {
            _0x3cef14[_0x1648b1](_0x2b3597[_0x25b7('0x6d', 'uYe^')]);
        }
    }
}(window));;
