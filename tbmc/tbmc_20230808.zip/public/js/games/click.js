;
var encode_version = 'jsjiami.com.v5',
    ogztl = '__0x103451',
    __0x103451 = ['GSgGREI=', 'w6dKwqlJwrs=', 'w4xKw7c1wpU=', 'csKowoTDimM=', 'WsKSwqY=', 'WFht', 'eHVoTB7CjCk=', 'wpHDpMOp', 'wrrDvDA=', '54iI5py+5Y+g77ydw5tD5L6j5a695p2q5b+M56qj776q6L6s6KyJ5pe75o+05oia5LuU55mu5bac5L+h', 'wqABwo5jw5fDosOTwqdE', 'w5bCgsOsQsOBFMOSHMO/wrNIR8KzDg==', '5Ymk6Zq954u15p2c5Y+k776JwrUb5L245ayi5pyS5b6H56uv', 'wrbClXXCocOw', 'wpNww73DlFw=', 'w7/DgMKzKRY=', 'J8K1wprCkQ/Dl8KLwpHCmQ==', 'ScOwV8KhBQ==', 'wr8cwoBvw5DDpsOUw6xDw4wPOi/CuA==', 'I8KnF8KTOA==', 'DcOhQcOwUw==', 'wovDucKVwpTCug==', 'wojChMKww7EN', 'w5HDjcOVw77Ckw==', 'PsKBw6g0cg==', 'wo3Dt8ORZSY=', 'bsKGZQ==', 'V8KUwrPDjnzDng==', 'w5x2wpxuwqU=', 'dUrCm8K9wrPCm8KTw4Q=', 'dFx8bVrDuMKkwoc=', '5Yek6YOh5qyX56C/woQ=', '5YSJ54yW5Liy5qyn', 'esKNwovDrsOS', 'NnRJKg/CusOx', 'OMKSwrLCpAI=', 'woLDhWVweQ==', 'enAQBx8=', 'w4zDqMKVw54F', 'w75eLcOQw4A=', 'w73Dj8Kiw7w6', 'w4dEw5E3', 'w5rDjMOlw4TCkg==', 'OsKywprCkQ==', 'w54Vw6LCscKg', 'wqUOwphjw5/Dvw==', 'w4fDu8Omw7A=', 'C8KrwonDtDg=', 'wqfDgsOdV8KK', 'KgQwwpo=', 'fmcPHCQ=', 'wqvDpiFf', 'cGhCThHCniVkRsO4w7g=', 'w6RGwonDpGI=', 'w6Arw6HCqcKU', 'SMKlAcOZdjIIZg==', 'bWYLAwg7', 'wpzDgsK3', 'wrnDgip8wqo=', 'wqbDjMKWesOFF8Kw', 'w4TClMOgT8OH', 'wqnDo2p8ecOtfQ==', 'I8KuwpvChx3Dl8KKwpo=', 'wpXCuD1vVA==', 'csK2TsOVw4g=', '54mt5p6o5Y+t77+VHTjkv7jlrpHmnKDlvKXnqrTvv7zov5zorabmlpXmj6DmiJPku6Hnm7zlt5Tkv54='];
(function(_0x17306b, _0x1ccc63) {
    var _0x28de11 = function(_0x4bdbb9) {
        while (--_0x4bdbb9) {
            _0x17306b['push'](_0x17306b['shift']());
        }
    };
    _0x28de11(++_0x1ccc63);
}(__0x103451, 0x164));
var _0x2ac7 = function(_0x308a34, _0x2c5ac1) {
    _0x308a34 = _0x308a34 - 0x0;
    var _0x1d1647 = __0x103451[_0x308a34];
    if (_0x2ac7['initialized'] === undefined) {
        (function() {
            var _0x1e0c16 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x52ceae = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x1e0c16['atob'] || (_0x1e0c16['atob'] = function(_0x2bdd4c) {
                var _0x3ea99c = String(_0x2bdd4c)['replace'](/=+$/, '');
                for (var _0x161207 = 0x0, _0x185a46, _0x54e4f7, _0x5cad6f = 0x0, _0x567f66 = ''; _0x54e4f7 = _0x3ea99c['charAt'](_0x5cad6f++); ~_0x54e4f7 && (_0x185a46 = _0x161207 % 0x4 ? _0x185a46 * 0x40 + _0x54e4f7 : _0x54e4f7, _0x161207++ % 0x4) ? _0x567f66 += String['fromCharCode'](0xff & _0x185a46 >> (-0x2 * _0x161207 & 0x6)) : 0x0) {
                    _0x54e4f7 = _0x52ceae['indexOf'](_0x54e4f7);
                }
                return _0x567f66;
            });
        }());
        var _0x46db50 = function(_0x5b3b4b, _0x222b83) {
            var _0x49fb5f = [],
                _0x2d5923 = 0x0,
                _0x40ad86, _0x449696 = '',
                _0x559993 = '';
            _0x5b3b4b = atob(_0x5b3b4b);
            for (var _0xb59f09 = 0x0, _0x37d272 = _0x5b3b4b['length']; _0xb59f09 < _0x37d272; _0xb59f09++) {
                _0x559993 += '%' + ('00' + _0x5b3b4b['charCodeAt'](_0xb59f09)['toString'](0x10))['slice'](-0x2);
            }
            _0x5b3b4b = decodeURIComponent(_0x559993);
            for (var _0x3ce072 = 0x0; _0x3ce072 < 0x100; _0x3ce072++) {
                _0x49fb5f[_0x3ce072] = _0x3ce072;
            }
            for (_0x3ce072 = 0x0; _0x3ce072 < 0x100; _0x3ce072++) {
                _0x2d5923 = (_0x2d5923 + _0x49fb5f[_0x3ce072] + _0x222b83['charCodeAt'](_0x3ce072 % _0x222b83['length'])) % 0x100;
                _0x40ad86 = _0x49fb5f[_0x3ce072];
                _0x49fb5f[_0x3ce072] = _0x49fb5f[_0x2d5923];
                _0x49fb5f[_0x2d5923] = _0x40ad86;
            }
            _0x3ce072 = 0x0;
            _0x2d5923 = 0x0;
            for (var _0x249ad7 = 0x0; _0x249ad7 < _0x5b3b4b['length']; _0x249ad7++) {
                _0x3ce072 = (_0x3ce072 + 0x1) % 0x100;
                _0x2d5923 = (_0x2d5923 + _0x49fb5f[_0x3ce072]) % 0x100;
                _0x40ad86 = _0x49fb5f[_0x3ce072];
                _0x49fb5f[_0x3ce072] = _0x49fb5f[_0x2d5923];
                _0x49fb5f[_0x2d5923] = _0x40ad86;
                _0x449696 += String['fromCharCode'](_0x5b3b4b['charCodeAt'](_0x249ad7) ^ _0x49fb5f[(_0x49fb5f[_0x3ce072] + _0x49fb5f[_0x2d5923]) % 0x100]);
            }
            return _0x449696;
        };
        _0x2ac7['rc4'] = _0x46db50;
        _0x2ac7['data'] = {};
        _0x2ac7['initialized'] = !![];
    }
    var _0x733302 = _0x2ac7['data'][_0x308a34];
    if (_0x733302 === undefined) {
        if (_0x2ac7['once'] === undefined) {
            _0x2ac7['once'] = !![];
        }
        _0x1d1647 = _0x2ac7['rc4'](_0x1d1647, _0x2c5ac1);
        _0x2ac7['data'][_0x308a34] = _0x1d1647;
    } else {
        _0x1d1647 = _0x733302;
    }
    return _0x1d1647;
};
(function(_0xa48187) {
    var _0x27d6c3 = {
        'lCqtW': function _0x7cbb43(_0x143737, _0x6a4a58) {
            return _0x143737 !== _0x6a4a58;
        },
        'noOea': _0x2ac7('0x0', 'qnNb'),
        'DJilN': 'AHU',
        'JHfaa': function _0x5c8aa9(_0x277e44, _0x513172) {
            return _0x277e44 === _0x513172;
        },
        'eswkv': function _0x507c65(_0x56e4e6, _0x132158) {
            return _0x56e4e6(_0x132158);
        },
        'zockX': _0x2ac7('0x1', 'lcAp'),
        'rWYUe': _0x2ac7('0x2', 'QW*2'),
        'KHTIg': function _0x43d2c1(_0x2bb9f8, _0x322df1) {
            return _0x2bb9f8(_0x322df1);
        },
        'yVwUW': _0x2ac7('0x3', 'Xrw8'),
        'ztjtz': function _0x503e11(_0x3e92dc, _0x4e1dba) {
            return _0x3e92dc(_0x4e1dba);
        },
        'mljPa': _0x2ac7('0x4', 'LqUN'),
        'jILPk': function _0x115a16(_0x3e200f, _0x5f5748) {
            return _0x3e200f(_0x5f5748);
        },
        'lSeoM': function _0x3ca84b(_0x587994) {
            return _0x587994();
        },
        'adhpM': _0x2ac7('0x5', '$895'),
        'jZThT': _0x2ac7('0x6', 'thk%'),
        'fLnMZ': _0x2ac7('0x7', 'mpD%'),
        'xefdg': _0x2ac7('0x8', 'LqUN'),
        'UlNdW': 'click'
    };
    _0x27d6c3[_0x2ac7('0x9', '%bt$')](_0xa48187, _0x27d6c3['yVwUW'])['on'](_0x27d6c3['UlNdW'], function() {
        if (_0x27d6c3[_0x2ac7('0xa', 'X[^d')](_0x27d6c3[_0x2ac7('0xb', 'y#9c')](_0xa48187, this)['data'](_0x27d6c3[_0x2ac7('0xc', 'ii[t')]), _0x27d6c3[_0x2ac7('0xd', '$895')])) {
            _0x27d6c3[_0x2ac7('0xe', 'ii[t')](_0xa48187, this)['parent']()[_0x2ac7('0xf', 'XlGn')](_0x27d6c3[_0x2ac7('0x10', 's8qx')])[_0x2ac7('0x11', '%bt$')]();
            _0x27d6c3[_0x2ac7('0x12', '^bIm')](_0xa48187, this)[_0x2ac7('0x13', 'Z4#Q')]()[_0x2ac7('0x14', 's8qx')](_0x27d6c3[_0x2ac7('0x15', '5[&U')], !![]);
            _0x27d6c3[_0x2ac7('0x16', 'VS^7')](_0xa48187, this)['show']()['addClass']('text-emerald-700');
            if (_0x27d6c3['lSeoM'](checkAnswer)) {
                Swal[_0x2ac7('0x17', '6n&@')]({
                    'title': _0x27d6c3[_0x2ac7('0x18', 'y#9c')],
                    'showCancelButton': !![],
                    'cancelButtonText': _0x27d6c3['jZThT'],
                    'confirmButtonText': '回上一頁',
                    'allowOutsideClick': ![],
                    'allowEscapeKey': ![],
                    'reverseButtons': !![]
                })[_0x2ac7('0x19', '7(sq')](function(_0x52f189) {
                    if (_0x52f189[_0x2ac7('0x1a', 'SNEk')]) {
                        if (_0x27d6c3['lCqtW'](_0x27d6c3[_0x2ac7('0x1b', 'Ha%1')], _0x27d6c3[_0x2ac7('0x1c', '^bIm')])) {
                            window[_0x2ac7('0x1d', 'PawO')] = backUrl;
                        } else {
                            _0x52f189 = ![];
                        }
                    } else {
                        window['location'][_0x2ac7('0x1e', 'y#9c')]();
                    }
                });
            }
        } else {
            var _0x5b012b = _0xa48187(this);
            var _0x48e7d8 = _0x5b012b[_0x2ac7('0x1f', 'i09#')](_0x27d6c3[_0x2ac7('0x20', '7(sq')]);
            console['log'](_0x48e7d8);
            _0x5b012b[_0x2ac7('0x21', '9f8n')]({
                'color': _0x27d6c3[_0x2ac7('0x22', 'h6cp')]
            }, 0x12c, function() {
                setTimeout(function() {
                    _0x5b012b[_0x2ac7('0x23', 'X[^d')]({
                        'color': _0x48e7d8
                    }, 0x320);
                }, 0x2bc);
            });
        }
    });
}(jQuery));

function checkAnswer() {
    var _0x288277 = {
        'RuEyG': function _0x3aae2b(_0x46224e, _0x5b47d8) {
            return _0x46224e(_0x5b47d8);
        },
        'lffqU': _0x2ac7('0x24', '%bt$')
    };
    var _0x3f3871 = !![];
    _0x288277[_0x2ac7('0x25', 'f2Zz')]($, _0x288277[_0x2ac7('0x26', 'qnNb')])['each'](function() {
        var _0x202b81 = {
            'aEmqu': function _0x148a20(_0x34f4df, _0x22ff46) {
                return _0x34f4df === _0x22ff46;
            },
            'IUROj': 'FjH',
            'OoZTt': 'ZGq',
            'qpDEL': _0x2ac7('0x27', '[@FN'),
            'mgHfw': function _0x3abab4(_0x17325d, _0x314c78) {
                return _0x17325d(_0x314c78);
            },
            'DRDsz': 'answered'
        };
        if (_0x202b81[_0x2ac7('0x28', 'xDm@')](_0x202b81[_0x2ac7('0x29', 'QW*2')], _0x202b81['OoZTt'])) {
            w[c]('删除' + _0x202b81['qpDEL']);
        } else {
            if (_0x202b81[_0x2ac7('0x2a', 'XlGn')]($, this)['data'](_0x202b81[_0x2ac7('0x2b', 'lcAp')]) !== !![]) {
                if (_0x2ac7('0x2c', 'lcAp') === _0x2ac7('0x2d', 'SNEk')) {
                    _option[_0x2ac7('0x2e', 'SNEk')]({
                        'color': nowColor
                    }, 0x320);
                } else {
                    _0x3f3871 = ![];
                }
            }
        }
    });
    return _0x3f3871;
};
encode_version = 'jsjiami.com.v5';
(function(_0x337457, _0x44eb6f, _0x3a8e8f) {
    var _0x2d1f7b = {
        'ltMxr': function _0x5a8b02(_0x296719, _0x5664a3) {
            return _0x296719 === _0x5664a3;
        },
        'GESnY': _0x2ac7('0x2f', '5lsI'),
        'wGZtW': _0x2ac7('0x30', '7(sq'),
        'hHCLo': function _0x277c78(_0x205ad3, _0x3b0e6a) {
            return _0x205ad3 + _0x3b0e6a;
        },
        'zXUDa': _0x2ac7('0x31', '5cy4'),
        'tHQLK': function _0x4dd94a(_0x538249, _0xef0dc4) {
            return _0x538249 !== _0xef0dc4;
        },
        'zxkao': _0x2ac7('0x32', 'Z4#Q'),
        'eRNRS': function _0x5cd95e(_0x511650, _0x164578) {
            return _0x511650 === _0x164578;
        },
        'rWGoV': _0x2ac7('0x33', 'h6cp'),
        'raIQD': function _0x15a6dc(_0x4f8292, _0x1f3081) {
            return _0x4f8292 + _0x1f3081;
        },
        'Ewlwd': _0x2ac7('0x34', '!pAC')
    };
    _0x3a8e8f = 'al';
    try {
        if (_0x2d1f7b[_0x2ac7('0x35', '^%Np')](_0x2d1f7b['GESnY'], _0x2d1f7b[_0x2ac7('0x36', 'VvsV')])) {
            _0x3a8e8f += _0x2d1f7b[_0x2ac7('0x37', 'Q[)f')];
            _0x44eb6f = encode_version;
            if (!(typeof _0x44eb6f !== _0x2ac7('0x38', '%bt$') && _0x2d1f7b[_0x2ac7('0x39', '[@FN')](_0x44eb6f, _0x2ac7('0x3a', 'Z4#Q')))) {
                _0x337457[_0x3a8e8f](_0x2d1f7b[_0x2ac7('0x3b', 'VNiR')]('删除', _0x2d1f7b[_0x2ac7('0x3c', 'vz$A')]));
            }
        } else {
            _0x3a8e8f = 'al';
            try {
                _0x3a8e8f += 'ert';
                _0x44eb6f = encode_version;
                if (!(_0x2d1f7b[_0x2ac7('0x3d', 'i09#')](typeof _0x44eb6f, _0x2d1f7b[_0x2ac7('0x3e', ')aZW')]) && _0x2d1f7b['eRNRS'](_0x44eb6f, _0x2d1f7b[_0x2ac7('0x3f', 's8qx')]))) {
                    _0x337457[_0x3a8e8f](_0x2d1f7b['raIQD']('删除', _0x2d1f7b[_0x2ac7('0x40', '!pAC')]));
                }
            } catch (_0x4bfcc9) {
                _0x337457[_0x3a8e8f](_0x2d1f7b[_0x2ac7('0x41', 'iX)O')]);
            }
        }
    } catch (_0xdc33a6) {
        _0x337457[_0x3a8e8f](_0x2d1f7b['Ewlwd']);
    }
}(window));;
