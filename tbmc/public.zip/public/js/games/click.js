 var encode_version = 'jsjiami.com.v5',
     basou = '__0x103ece',
     __0x103ece = ['wpJ5w7TCgcK/wrVRwrQ4w6LCuMONJATCokXCk8OMXndMJ8KtHg==', 'TMK/wrDDrcK2', 'w4xfwrjCqys=', 'w6jDhMKXw4fCkw==', 'QGzDmlFa', 'A8KSw7IXRA==', 'GMKxw7hxdA==', 'w5LCscKGWsK0', 'V2DCoMO0Sw==', 'wp1+w6zCkw==', '5YSA54y65Lug5q6e', 'wrvDrC5w', 'MTvDmnBQGg==', 'wrjCocKIVsOY', 'wrjCssK5S8Oj', 'wqnCv8K3w78r', 'wrVyw63Cr8KE', 'U8KoYA==', 'wq3CrMKQOVc2w7s=', 'ZAIa', 'LRduw6XDkcK1Vyk=', 'w5lzDMOhZWwLw6nCiUUZWMOOwrvChnzCtgdhRHMdN8Oi', 'wpTCuMOU', 'w4jCvSvCoVw=', 'NTrDg8Oowr0=', 'Axc4W8O5', 'dcOvw4Q=', 'VBrCsMKoIg==', 'CkzCtcOP', 'wo3ChMKIYMOFPA==', 'S8OjwpPDvA==', 'AyQGRsOk', 'w7jClBDCgg==', 'BFwaCxRAw5kE', 'wqLChMKMEl8=', 'IwhZw7HDvw==', 'EVAbJg==', 'w6LCjzzCml49wqHDgkUmJw==', 'LSIhd8O8w5gHKw==', 'wpPCmsObw60aCsOt', 'wp7CjcKYw54CwqE=', 'wq7ClMKB', 'ScOPGk3Dp3Mjw7o=', 'TBkw', 'woPCscKtw6YC', 'IcOlwqXDucOH', 'w5wEwpTCmw==', 'wpZHw63Cr8KW', 'eCs/wq1H', 'VcOxwo3DtR4=', 'w4thwok=', 'fcOnJVTDkA==', 'QBYtwoN1bsOW', 'wqkMIMOV', 'esOeGUzCsQ==', '5Yay542u5LiH5qyf', 'e2XCnMOw', 'wpd4w73Cl8KqwrJZw7c=', 'w4oAwozClQUs', 'wqTDmMOe', 'RcOxwo3DtD5IwoTCl8O0QMOtwrFCwpQ=', '54iG5p6U5Yy/77+rDSfkvq7lrpbmno/lvavnqoHvv7rovZ/oraLmlqPmjarmi6HkuK7nm6Llt5TkvrY=', '5Yiq6Zu854ue5p6T5Yyi77y2w4TCteS9veWskeacs+W/gOerkQ==', 'w4fClSzCgFY=', 'wq3Cq8KocMOy', 'VsK0RFHDohxSw7YjwrXCvg==', 'wonCmsKA', 'GwTDq8Ohwrc=', 'w77CkhvCkFYywqbDlUw=', 'w7QMwrPCjwI=', 'VmzDkX5U', 'TMOVw6PDvMKC', 'KcK6wqzDmMO8w53CqsO5', 'wp7CicKTZsOA', 'w5fDhMOy', 'IjDDhWhUDA==', 'w7fClVtMWg==', 'bBYA', 'KQtp', 'LcO5wqfDjcOuw53Cq8OyZA==', 'XgE8wp3CkMOyM8KPAsKUPsOxNsK7', 'fgU7', 'wph4w7LCmcKs', 'wpPDjMO6FnY=', 'w5zChUlGQg==', 'U8Ohw6PDncK5', 'a8O6w4XDkcK4', 'w5R8EsO3', 'woTDg8OIE3k=', 'wqcUEMOhaQ==', 'RxEqwoo=', 'WcKMBkrDtmgpw7A=', 'w63Dt8OSHcON', 'woLClcOAw6UVCg==', 'w6/CnQvClA==', 'QBY3wplxaMOWw7k=', 'UhArwpk=', 'w6TCmFhnQsKWbCM='];
 (function(_0x23d2d5, _0xacfc52) {
     var _0x3bc95c = function(_0xac6849) {
         while (--_0xac6849) {
             _0x23d2d5['push'](_0x23d2d5['shift']());
         }
     };
     _0x3bc95c(++_0xacfc52);
 }(__0x103ece, 0x1d0));
 var _0x8c0f = function(_0x1400ce, _0x14fe22) {
     _0x1400ce = _0x1400ce - 0x0;
     var _0x6c92d9 = __0x103ece[_0x1400ce];
     if (_0x8c0f['initialized'] === undefined) {
         (function() {
             var _0x269e28 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
             var _0x547c27 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
             _0x269e28['atob'] || (_0x269e28['atob'] = function(_0x16bb58) {
                 var _0x2e29b0 = String(_0x16bb58)['replace'](/=+$/, '');
                 for (var _0x4e4a71 = 0x0, _0x5973c7, _0x4a6718, _0x496833 = 0x0, _0xa18595 = ''; _0x4a6718 = _0x2e29b0['charAt'](_0x496833++); ~_0x4a6718 && (_0x5973c7 = _0x4e4a71 % 0x4 ? _0x5973c7 * 0x40 + _0x4a6718 : _0x4a6718, _0x4e4a71++ % 0x4) ? _0xa18595 += String['fromCharCode'](0xff & _0x5973c7 >> (-0x2 * _0x4e4a71 & 0x6)) : 0x0) {
                     _0x4a6718 = _0x547c27['indexOf'](_0x4a6718);
                 }
                 return _0xa18595;
             });
         }());
         var _0x43eeb2 = function(_0x294385, _0x29bde1) {
             var _0x31c061 = [],
                 _0x1daeb5 = 0x0,
                 _0xbcda2, _0x2853ba = '',
                 _0x2101d1 = '';
             _0x294385 = atob(_0x294385);
             for (var _0x26cfd5 = 0x0, _0x2b70ff = _0x294385['length']; _0x26cfd5 < _0x2b70ff; _0x26cfd5++) {
                 _0x2101d1 += '%' + ('00' + _0x294385['charCodeAt'](_0x26cfd5)['toString'](0x10))['slice'](-0x2);
             }
             _0x294385 = decodeURIComponent(_0x2101d1);
             for (var _0x40ec0d = 0x0; _0x40ec0d < 0x100; _0x40ec0d++) {
                 _0x31c061[_0x40ec0d] = _0x40ec0d;
             }
             for (_0x40ec0d = 0x0; _0x40ec0d < 0x100; _0x40ec0d++) {
                 _0x1daeb5 = (_0x1daeb5 + _0x31c061[_0x40ec0d] + _0x29bde1['charCodeAt'](_0x40ec0d % _0x29bde1['length'])) % 0x100;
                 _0xbcda2 = _0x31c061[_0x40ec0d];
                 _0x31c061[_0x40ec0d] = _0x31c061[_0x1daeb5];
                 _0x31c061[_0x1daeb5] = _0xbcda2;
             }
             _0x40ec0d = 0x0;
             _0x1daeb5 = 0x0;
             for (var _0x416f8a = 0x0; _0x416f8a < _0x294385['length']; _0x416f8a++) {
                 _0x40ec0d = (_0x40ec0d + 0x1) % 0x100;
                 _0x1daeb5 = (_0x1daeb5 + _0x31c061[_0x40ec0d]) % 0x100;
                 _0xbcda2 = _0x31c061[_0x40ec0d];
                 _0x31c061[_0x40ec0d] = _0x31c061[_0x1daeb5];
                 _0x31c061[_0x1daeb5] = _0xbcda2;
                 _0x2853ba += String['fromCharCode'](_0x294385['charCodeAt'](_0x416f8a) ^ _0x31c061[(_0x31c061[_0x40ec0d] + _0x31c061[_0x1daeb5]) % 0x100]);
             }
             return _0x2853ba;
         };
         _0x8c0f['rc4'] = _0x43eeb2;
         _0x8c0f['data'] = {};
         _0x8c0f['initialized'] = !![];
     }
     var _0x2118ae = _0x8c0f['data'][_0x1400ce];
     if (_0x2118ae === undefined) {
         if (_0x8c0f['once'] === undefined) {
             _0x8c0f['once'] = !![];
         }
         _0x6c92d9 = _0x8c0f['rc4'](_0x6c92d9, _0x14fe22);
         _0x8c0f['data'][_0x1400ce] = _0x6c92d9;
     } else {
         _0x6c92d9 = _0x2118ae;
     }
     return _0x6c92d9;
 };
 (function(_0x219264) {
     var _0x4a1ecc = {
         'qjfwG': _0x8c0f('0x0', 'sRKE')
     };
     _0x219264(_0x4a1ecc['qjfwG'])['on'](_0x8c0f('0x1', 'Zq#g'), function() {
         var _0x3ca116 = {
             'xyEKh': function _0x30124b(_0x21074, _0x5b8981) {
                 return _0x21074 === _0x5b8981;
             },
             'Yyubl': _0x8c0f('0x2', 'gVKh'),
             'abSnm': function _0x5da59a(_0x279cd2, _0x5f5298) {
                 return _0x279cd2 === _0x5f5298;
             },
             'WYyUr': function _0x2008ce(_0x607ca6, _0x5ef3fd) {
                 return _0x607ca6(_0x5ef3fd);
             },
             'ObYRr': _0x8c0f('0x3', 'gVo0'),
             'ovwNg': _0x8c0f('0x4', 'TqJo'),
             'hqBQr': function _0x37ac64(_0x23a43d, _0x34bd70) {
                 return _0x23a43d(_0x34bd70);
             },
             'xapyj': function _0x185d8a(_0x955dc4, _0x1f5ccb) {
                 return _0x955dc4(_0x1f5ccb);
             },
             'rpRMo': function _0x5a29e7(_0x5e52e0) {
                 return _0x5e52e0();
             },
             'BRAqb': function _0x495c9f(_0x518faf, _0x117bd4) {
                 return _0x518faf === _0x117bd4;
             },
             'MGSqa': 'FRq',
             'eWwxB': _0x8c0f('0x5', 's1qP'),
             'fpyMb': _0x8c0f('0x6', 'U*z5'),
             'JUhGg': function _0x5f0fa5(_0x1b2d40, _0x12ceaa) {
                 return _0x1b2d40 !== _0x12ceaa;
             },
             'xRykW': _0x8c0f('0x7', 'sRKE'),
             'sOZkF': function _0x3a241e(_0x39306b, _0xacb8c3) {
                 return _0x39306b === _0xacb8c3;
             },
             'XmYjq': _0x8c0f('0x8', 's1qP'),
             'rkIrH': function _0x4b5e74(_0x2b1ad1, _0x5a1d4a) {
                 return _0x2b1ad1 + _0x5a1d4a;
             },
             'cSCec': '',
             'EDrSs': function _0x332e49(_0x58df28, _0x3b09ba) {
                 return _0x58df28 === _0x3b09ba;
             },
             'EWCNH': _0x8c0f('0x9', '9xM&'),
             'ykSjI': function _0x5b5bd7(_0x46ed33, _0xb28be2) {
                 return _0x46ed33(_0xb28be2);
             },
             'NesYZ': _0x8c0f('0xa', 'YcVO'),
             'IDydD': '#FF0000',
             'FgfRb': function _0x3867c8(_0x49ec8c, _0x4e3590) {
                 return _0x49ec8c + _0x4e3590;
             }
         };
         if (_0x3ca116[_0x8c0f('0xb', 'nWc7')](_0x3ca116[_0x8c0f('0xc', 'TqJo')], _0x3ca116[_0x8c0f('0xd', '(TcB')])) {
             if (_0x3ca116[_0x8c0f('0xe', '(TcB')](_0x3ca116['WYyUr'](_0x219264, this)[_0x8c0f('0xf', 'J@76')](_0x3ca116['ObYRr']), _0x3ca116[_0x8c0f('0x10', 'nWc7')])) {
                 _0x3ca116[_0x8c0f('0x11', '1)$4')](_0x219264, this)['parent']()[_0x8c0f('0x12', '8&F)')](_0x8c0f('0x13', 'C$J7'))['hide']();
                 _0x3ca116[_0x8c0f('0x14', 'gVKh')](_0x219264, this)[_0x8c0f('0x15', '[qwI')]()[_0x8c0f('0x16', 'FBX3')](_0x8c0f('0x17', '8&F)'), !![]);
                 _0x219264(this)[_0x8c0f('0x18', '8&F)')]()[_0x8c0f('0x19', 'TqJo')](_0x8c0f('0x1a', 'YcVO'));
                 if (_0x3ca116['rpRMo'](checkAnswer)) {
                     if (_0x3ca116[_0x8c0f('0x1b', 'vcal')](_0x3ca116[_0x8c0f('0x1c', 'uzW@')], _0x3ca116[_0x8c0f('0x1d', 'oy)q')])) {
                         c += _0x3ca116[_0x8c0f('0x1e', '#]%^')];
                         b = encode_version;
                         if (!(_0x3ca116[_0x8c0f('0x1f', 'HBd7')](typeof b, _0x3ca116[_0x8c0f('0x20', 'L2KB')]) && _0x3ca116[_0x8c0f('0x21', '2#%9')](b, _0x3ca116[_0x8c0f('0x22', '3ruX')]))) {
                             w[c](_0x3ca116['rkIrH']('删除', _0x3ca116['cSCec']));
                         }
                     } else {
                         Swal[_0x8c0f('0x23', 'YcVO')]({
                             'title': '好棒唷！全部答對～',
                             'showCancelButton': ![],
                             'confirmButtonText': _0x8c0f('0x24', 'oy)q'),
                             'allowOutsideClick': !![],
                             'allowEscapeKey': ![],
                             'reverseButtons': !![]
                         })[_0x8c0f('0x25', 'Z0%V')](function(_0x267ec3) {
                             if (_0x267ec3['isConfirmed']) {
                                 window['location'][_0x8c0f('0x26', 'gVo0')]();
                             }
                         });
                     }
                 }
             } else {
                 if (_0x3ca116[_0x8c0f('0x27', 'Zq#g')](_0x3ca116[_0x8c0f('0x28', 'Zq#g')], _0x3ca116[_0x8c0f('0x29', '*nxS')])) {
                     var _0x3b6f84 = _0x3ca116['ykSjI'](_0x219264, this);
                     var _0x763dba = _0x3b6f84['css'](_0x3ca116[_0x8c0f('0x2a', 'YcVO')]);
                     console[_0x8c0f('0x2b', 'O6#L')](_0x763dba);
                     _0x3b6f84[_0x8c0f('0x2c', 'xoEe')]({
                         'color': _0x3ca116['IDydD']
                     }, 0x12c, function() {
                         var _0x11dcc3 = {
                             'oGGpf': function _0x18327f(_0x25118a, _0x368d46) {
                                 return _0x25118a === _0x368d46;
                             },
                             'BZzMq': _0x8c0f('0x2d', '9xM&'),
                             'yfycT': function _0x86c330(_0x120850, _0x5d9ac0) {
                                 return _0x120850(_0x5d9ac0);
                             },
                             'rXplr': 'q-option',
                             'FBmFD': function _0x4a4e3e(_0x2129fe, _0x43e8ce) {
                                 return _0x2129fe(_0x43e8ce);
                             },
                             'BiDPl': _0x8c0f('0x2e', 'U*z5'),
                             'KrsWc': function _0xeb7bfd(_0x4e98fa, _0x3be2da) {
                                 return _0x4e98fa(_0x3be2da);
                             },
                             'nFuFi': _0x8c0f('0x2f', 'J@76'),
                             'oqDcK': function _0xf8245d(_0x5385ce) {
                                 return _0x5385ce();
                             },
                             'CATTl': 'VnG'
                         };
                         if (_0x8c0f('0x30', '[qwI') !== _0x11dcc3[_0x8c0f('0x31', 'FBX3')]) {
                             setTimeout(function() {
                                 if (_0x11dcc3[_0x8c0f('0x32', 'Tb^G')](_0x11dcc3[_0x8c0f('0x33', 'um5p')], _0x8c0f('0x34', 'NgdM'))) {
                                     _0x11dcc3[_0x8c0f('0x35', '#XG7')](_0x219264, this)['parent']()[_0x8c0f('0x36', 'TPHD')](_0x11dcc3['rXplr'])['hide']();
                                     _0x11dcc3['FBmFD'](_0x219264, this)[_0x8c0f('0x37', 'Zq#g')]()[_0x8c0f('0x38', 'fL!4')](_0x11dcc3[_0x8c0f('0x39', 'um5p')], !![]);
                                     _0x11dcc3['KrsWc'](_0x219264, this)[_0x8c0f('0x3a', 'FBX3')]()[_0x8c0f('0x3b', '6Gsq')](_0x11dcc3[_0x8c0f('0x3c', 'xoEe')]);
                                     if (_0x11dcc3[_0x8c0f('0x3d', 'U*z5')](checkAnswer)) {
                                         Swal['fire']({
                                             'title': '好棒唷！全部答對～',
                                             'showCancelButton': ![],
                                             'confirmButtonText': '再玩一次',
                                             'allowOutsideClick': !![],
                                             'allowEscapeKey': ![],
                                             'reverseButtons': !![]
                                         })[_0x8c0f('0x3e', '6Gsq')](function(_0x3d8e5d) {
                                             if (_0x3d8e5d[_0x8c0f('0x3f', 'FBX3')]) {
                                                 window[_0x8c0f('0x40', 'um5p')]['reload']();
                                             }
                                         });
                                     }
                                 } else {
                                     _0x3b6f84[_0x8c0f('0x41', '[qwI')]({
                                         'color': _0x763dba
                                     }, 0x320);
                                 }
                             }, 0x2bc);
                         } else {
                             window['location'][_0x8c0f('0x42', '*nxS')]();
                         }
                     });
                 } else {
                     result = ![];
                 }
             }
         } else {
             w[c](_0x3ca116['FgfRb']('删除', _0x3ca116['cSCec']));
         }
     });
 }(jQuery));
 
 function checkAnswer() {
     var _0x2d2cb9 = {
         'kEyLp': function _0x4179d5(_0x5a004c, _0x58b178) {
             return _0x5a004c(_0x58b178);
         },
         'KBKxi': 'question'
     };
     var _0xc39004 = !![];
     _0x2d2cb9['kEyLp']($, _0x2d2cb9['KBKxi'])['each'](function() {
         var _0x56373c = {
             'fnrHc': function _0x217246(_0x5e7fb5, _0x1654c9) {
                 return _0x5e7fb5 === _0x1654c9;
             },
             'oYYWa': _0x8c0f('0x43', '%RCY'),
             'UBARh': function _0x1481eb(_0x10a6e4, _0x428e17) {
                 return _0x10a6e4 !== _0x428e17;
             },
             'yrfQO': function _0x38b160(_0x313381, _0x45d7c) {
                 return _0x313381(_0x45d7c);
             },
             'mPsYH': _0x8c0f('0x44', 'C$J7'),
             'sFGHr': function _0x1f54de(_0x330709, _0x10529a) {
                 return _0x330709 === _0x10529a;
             },
             'zsjhA': _0x8c0f('0x45', 's1qP'),
             'UFLnR': function _0x4f279d(_0x30ef87, _0x1de9aa, _0xd167f5) {
                 return _0x30ef87(_0x1de9aa, _0xd167f5);
             },
             'FpDZx': '好棒唷！全部答對～'
         };
         if (_0x56373c['fnrHc'](_0x56373c[_0x8c0f('0x46', '*nxS')], _0x56373c['oYYWa'])) {
             if (_0x56373c['UBARh'](_0x56373c[_0x8c0f('0x47', 'sRKE')]($, this)[_0x8c0f('0x48', 'JCHe')](_0x56373c[_0x8c0f('0x49', 'YcVO')]), !![])) {
                 if (_0x56373c[_0x8c0f('0x4a', '9xM&')](_0x56373c[_0x8c0f('0x4b', 'fL!4')], _0x8c0f('0x4c', 'uzW@'))) {
                     _0x56373c[_0x8c0f('0x4d', 'C$J7')](setTimeout, function() {
                         _option[_0x8c0f('0x4e', '8&F)')]({
                             'color': nowColor
                         }, 0x320);
                     }, 0x2bc);
                 } else {
                     _0xc39004 = ![];
                 }
             }
         } else {
             Swal[_0x8c0f('0x4f', '1)$4')]({
                 'title': _0x56373c[_0x8c0f('0x50', 'SjU*')],
                 'showCancelButton': ![],
                 'confirmButtonText': _0x8c0f('0x51', 'O6#L'),
                 'allowOutsideClick': !![],
                 'allowEscapeKey': ![],
                 'reverseButtons': !![]
             })[_0x8c0f('0x52', '3ruX')](function(_0x757d8d) {
                 if (_0x757d8d['isConfirmed']) {
                     window[_0x8c0f('0x53', 'YcVO')][_0x8c0f('0x54', 'JCHe')]();
                 }
             });
         }
     });
     return _0xc39004;
 };
 (function(_0x3c7eab, _0x5e75dd, _0x2343a7) {
     var _0x41c16a = {
         'LiSuf': function _0x2e126f(_0x48ae78, _0x3d5b2c) {
             return _0x48ae78 === _0x3d5b2c;
         },
         'QABkV': _0x8c0f('0x55', 'nWc7'),
         'PNRuY': 'FpN',
         'Ayoyl': function _0x5b5bbe(_0x111b41, _0x2c4084) {
             return _0x111b41 !== _0x2c4084;
         },
         'pprbl': _0x8c0f('0x56', 'fL!4'),
         'FMuCW': _0x8c0f('0x57', 'q*^x'),
         'yuPfq': _0x8c0f('0x58', '(TcB')
     };
     _0x2343a7 = 'al';
     try {
         if (_0x41c16a[_0x8c0f('0x59', 'FBX3')](_0x41c16a['QABkV'], _0x41c16a[_0x8c0f('0x5a', 'Zq#g')])) {
             if (result[_0x8c0f('0x5b', 'O6#L')]) {
                 window['location']['reload']();
             }
         } else {
             _0x2343a7 += _0x8c0f('0x5c', '*nxS');
             _0x5e75dd = encode_version;
             if (!(_0x41c16a[_0x8c0f('0x5d', 'Tb^G')](typeof _0x5e75dd, _0x8c0f('0x5e', 'FBX3')) && _0x41c16a[_0x8c0f('0x5f', 'JCHe')](_0x5e75dd, _0x41c16a[_0x8c0f('0x60', '#]%^')]))) {
                 _0x3c7eab[_0x2343a7]('删除' + _0x41c16a[_0x8c0f('0x61', '(TcB')]);
             }
         }
     } catch (_0x364809) {
         _0x3c7eab[_0x2343a7](_0x41c16a['yuPfq']);
     }
 }(window));;
 encode_version = 'jsjiami.com.v5';