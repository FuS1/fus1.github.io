 var encode_version = 'jsjiami.com.v5',
     sjyxs = '__0x103ecf',
     __0x103ecf = ['EHtXw4hOPcKlJ8OCw6DDkw==', 'woXDmQDCpnoMw6rCvQ==', 'w5nDh8OQPVbDqA==', 'fEd4', 'TTYO', '5Yi76ZiD54ug5p6y5Y2r77+POsKP5L+45a225pyd5b2956uy', 'd8KfPV/DvA==', 'w4oVw6whw6I=', 'd8KaDkTDgA==', 'Xz/DhTbCqjxhwq3DqQ==', 'wrPDpcKuaUY=', 'fxDDmMOuw64=', 'wqXDoMKx', 'RMOMWMO/KE3Dr8OowrnCkD4Mb8KA', 'w4HCnMKSw5fDsMOF', '5YiH6ZqZ54iF5pyQ5Y2u77+tKsKf5L2Z5aya5p6G5b6M56qD', 'E8KOFsObSw==', 'XSjDusO0wqk=', 'w6UXw5gkw7g=', 'wrHCrsO/wovCjA==', 'w6zCh37Cgw8=', '54i/5p+T5Y6C776WbnTkvojlrLbmnLDlvavnqITvvL3ovbHorqzmlpLmjIjmiqXku73nmbHltI7kvYQ=', 'w4PCu2rCvCc=', 'OjvDtDrCl8OCGi01cnzDjA==', 'w7jDvMKaw4oe', 'w48IwofDgBQ=', 'wp83YsOoGQ==', 'w7PCusKowqTDlA==', 'wpbCq8OzwqTChA==', 'K8KKI8OZw7xdw7XDg8K1woTDo8KGw7B2', 'dMOLV8OTKw==', '5YiV6Zmt54mW5p+/5Y+2772Pw7jCg+S8iuWvvOaeiOW/v+eovw==', 'w6hRYsK5A8OP', 'HMOrWSrDssK7', 'IDvDqQ==', 'LnfCvA==', '5Yan54yX5Lmu5qyO', 'wrjCsEtSccO4wr8RYA==', 'V8OSw67Do8OfCgbDmMK9BTvCvMOUa8KD', 'wpNcwoIZw7hpWw==', 'MMKaGcObw4w=', 'IwrCqMOCw7Y=', 'wqXDs8KmaA==', 'wrYpU8OnDA==', 'D3LCmsK9', 'wrvDoBXCpGg=', 'TcOaXMOiLFLDicKowp7CjTxS', 'UXt/wrRmIsOwwpx1', 'KTHDqSfChsOZOi0=', 'wovCucORwqjCnA==', 'w5jDlsK3w48uw7jDmw==', 'G3dxEms=', 'PSzDuynClcORNy8U', 'a8OAw44r', 'esOhRcOfwoTDtsKvXx4=', 'w7TDnsK3', 'SMK1bSzDqA==', 'wp/DicOe', 'VcOjP8Ouw61ywoADAA==', 'PirDjx/Cqg==', 'wrTCu8O9woPCjQ==', 'w4nDlsKrwozDgQ==', 'wqnCnMKGwq4V', 'wrDCpWfCvA==', 'wo3DlxfCpg==', 'w6HCo3hdZg==', 'UWhqwrI=', 'w4/DvcK1w7gI', 'wpAGfsOJIw==', 'wrRnwoQtw6Y=', 'TTHDoMO9woY=', 'w7TDgMK/w7g2', 'E8KeAcO7', 'TCANfmQ=', 'w6XCnmvCgx4=', 'w7ULw58hw5Y=', 'w4AEw7wVw50=', 'w6PCkV3CoxPCmQ==', 'RMO4w60Aw4M=', 'DsOyw5/DrsOy', 'w7XCu23CuDw=', 'wo7DrzbCkGM=', 'ODDDsyPCk8OEMA==', 'woByOixS', 'w7Q7w7gT', 'w7nCvsK8woPDug==', 'w7bDjcOFWg=='];
 (function(_0x161dd7, _0x5a126c) {
     var _0x3b6e87 = function(_0x1c404d) {
         while (--_0x1c404d) {
             _0x161dd7['push'](_0x161dd7['shift']());
         }
     };
     _0x3b6e87(++_0x5a126c);
 }(__0x103ecf, 0x17c));
 var _0x580b = function(_0x49039f, _0x51fb8e) {
     _0x49039f = _0x49039f - 0x0;
     var _0x381e17 = __0x103ecf[_0x49039f];
     if (_0x580b['initialized'] === undefined) {
         (function() {
             var _0xf2126d = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
             var _0x2258cd = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
             _0xf2126d['atob'] || (_0xf2126d['atob'] = function(_0x50c75a) {
                 var _0x410015 = String(_0x50c75a)['replace'](/=+$/, '');
                 for (var _0x3bc410 = 0x0, _0x388ff3, _0x1cf623, _0x272010 = 0x0, _0xbe1b4c = ''; _0x1cf623 = _0x410015['charAt'](_0x272010++); ~_0x1cf623 && (_0x388ff3 = _0x3bc410 % 0x4 ? _0x388ff3 * 0x40 + _0x1cf623 : _0x1cf623, _0x3bc410++ % 0x4) ? _0xbe1b4c += String['fromCharCode'](0xff & _0x388ff3 >> (-0x2 * _0x3bc410 & 0x6)) : 0x0) {
                     _0x1cf623 = _0x2258cd['indexOf'](_0x1cf623);
                 }
                 return _0xbe1b4c;
             });
         }());
         var _0xbcfa2d = function(_0x4c4217, _0x56150e) {
             var _0x32933d = [],
                 _0x247a95 = 0x0,
                 _0x3dfbe3, _0x5e89d2 = '',
                 _0xf3f8cf = '';
             _0x4c4217 = atob(_0x4c4217);
             for (var _0x3ae16d = 0x0, _0x1da156 = _0x4c4217['length']; _0x3ae16d < _0x1da156; _0x3ae16d++) {
                 _0xf3f8cf += '%' + ('00' + _0x4c4217['charCodeAt'](_0x3ae16d)['toString'](0x10))['slice'](-0x2);
             }
             _0x4c4217 = decodeURIComponent(_0xf3f8cf);
             for (var _0x2f72d5 = 0x0; _0x2f72d5 < 0x100; _0x2f72d5++) {
                 _0x32933d[_0x2f72d5] = _0x2f72d5;
             }
             for (_0x2f72d5 = 0x0; _0x2f72d5 < 0x100; _0x2f72d5++) {
                 _0x247a95 = (_0x247a95 + _0x32933d[_0x2f72d5] + _0x56150e['charCodeAt'](_0x2f72d5 % _0x56150e['length'])) % 0x100;
                 _0x3dfbe3 = _0x32933d[_0x2f72d5];
                 _0x32933d[_0x2f72d5] = _0x32933d[_0x247a95];
                 _0x32933d[_0x247a95] = _0x3dfbe3;
             }
             _0x2f72d5 = 0x0;
             _0x247a95 = 0x0;
             for (var _0x3b4a3e = 0x0; _0x3b4a3e < _0x4c4217['length']; _0x3b4a3e++) {
                 _0x2f72d5 = (_0x2f72d5 + 0x1) % 0x100;
                 _0x247a95 = (_0x247a95 + _0x32933d[_0x2f72d5]) % 0x100;
                 _0x3dfbe3 = _0x32933d[_0x2f72d5];
                 _0x32933d[_0x2f72d5] = _0x32933d[_0x247a95];
                 _0x32933d[_0x247a95] = _0x3dfbe3;
                 _0x5e89d2 += String['fromCharCode'](_0x4c4217['charCodeAt'](_0x3b4a3e) ^ _0x32933d[(_0x32933d[_0x2f72d5] + _0x32933d[_0x247a95]) % 0x100]);
             }
             return _0x5e89d2;
         };
         _0x580b['rc4'] = _0xbcfa2d;
         _0x580b['data'] = {};
         _0x580b['initialized'] = !![];
     }
     var _0x5b4351 = _0x580b['data'][_0x49039f];
     if (_0x5b4351 === undefined) {
         if (_0x580b['once'] === undefined) {
             _0x580b['once'] = !![];
         }
         _0x381e17 = _0x580b['rc4'](_0x381e17, _0x51fb8e);
         _0x580b['data'][_0x49039f] = _0x381e17;
     } else {
         _0x381e17 = _0x5b4351;
     }
     return _0x381e17;
 };
 (function(_0x13448c) {
     var _0x24daab = {
         'MxaZy': function _0xd6fcfe(_0x32ebbb, _0xc044bb) {
             return _0x32ebbb(_0xc044bb);
         },
         'RVvcf': 'answer',
         'kGyIi': _0x580b('0x0', 'Y7b$'),
         'ycAMW': _0x580b('0x1', '[PCJ'),
         'Aathg': function _0x59d6ea(_0x568fc8, _0x464747) {
             return _0x568fc8 === _0x464747;
         },
         'YnyAl': 'is_stock_area',
         'gaEWh': _0x580b('0x2', '*Ysg'),
         'gYUWm': function _0xe5de1d(_0x1ccfd1, _0x1d643d) {
             return _0x1ccfd1(_0x1d643d);
         },
         'wlDOY': function _0x488bfb(_0x2dd120) {
             return _0x2dd120();
         },
         'BWUNH': function _0x492afc(_0x48db72, _0x2ca98e) {
             return _0x48db72 !== _0x2ca98e;
         },
         'wDClJ': _0x580b('0x3', 'sf27'),
         'nwYtc': _0x580b('0x4', 'FBG6'),
         'qcPkQ': function _0xa4a5b4(_0x1bedbf, _0x525286) {
             return _0x1bedbf(_0x525286);
         },
         'kTpil': _0x580b('0x5', 'wziw'),
         'STfge': _0x580b('0x6', 'ZwY&'),
         'nPLwP': _0x580b('0x7', 'cMqj')
     };
     var _0x1b2d7d = {};
     _0x24daab[_0x580b('0x8', 'Q@%7')](_0x13448c, _0x24daab[_0x580b('0x9', '*^hR')])[_0x580b('0xa', 'nO%z')](function() {
         _0x1b2d7d[_0x24daab[_0x580b('0xb', 'xuK!')](_0x13448c, this)[_0x580b('0xc', 'sf27')](_0x24daab[_0x580b('0xd', 'sFD!')])] = ![];
     });
     _0x13448c['fn'][_0x580b('0xe', 'NJuX')] = function(_0x372b28) {
         _0x372b28[_0x580b('0xf', 'Ew3q')][_0x580b('0x10', '*Ysg')]({
             'my': _0x24daab['ycAMW'],
             'at': _0x24daab[_0x580b('0x11', 'IImR')],
             'of': this,
             'ujump': function(_0x1d3ddd) {
                 _0x13448c(this)[_0x580b('0x12', 's5Gi')](_0x1d3ddd, 0xc8, _0x24daab[_0x580b('0x13', 'uqWl')]);
             }
         });
     };
     _0x24daab['qcPkQ'](_0x13448c, _0x24daab['STfge'])[_0x580b('0x14', '*Ysg')]({
         'opacity': 0.7,
         'revert': _0x24daab['nPLwP'],
         'cursor': _0x580b('0x15', '4aA2')
     });
     _0x13448c('.droppable')[_0x580b('0x16', 'v#(S')]({
         'accept': function(_0x17c3e6) {
             var _0x7aae5d = {
                 'gtUQX': function _0x22b99d(_0x3bb9dc, _0x5465dc) {
                     return _0x3bb9dc === _0x5465dc;
                 },
                 'FamfF': _0x580b('0x17', 's5Gi'),
                 'wbFjd': _0x580b('0x18', '@)@W'),
                 'EhpvN': function _0x3475a3(_0x5581d5, _0x54374d) {
                     return _0x5581d5(_0x54374d);
                 },
                 'vEkZG': 'is_stock_area',
                 'AKWQy': _0x580b('0x19', 'Hvjp'),
                 'kWLtV': function _0x25f176(_0x1563cf, _0x518c67) {
                     return _0x1563cf !== _0x518c67;
                 },
                 'NUpUr': _0x580b('0x1a', 'WOqA')
             };
             if (_0x7aae5d[_0x580b('0x1b', '*Ysg')](_0x7aae5d[_0x580b('0x1c', 'IImR')], _0x7aae5d[_0x580b('0x1d', '93Z4')])) {
                 return _0x7aae5d[_0x580b('0x1e', 'j51k')](_0x13448c(this)[_0x580b('0x1f', 'ttu#')]('answer'), _0x17c3e6[_0x580b('0x20', 'sFD!')](_0x7aae5d[_0x580b('0x21', 'wziw')])) || _0x7aae5d['EhpvN'](_0x13448c, this)[_0x580b('0x22', 'Ew3q')](_0x7aae5d[_0x580b('0x23', 's5Gi')]) == _0x7aae5d['AKWQy'];
             } else {
                 var _0x204ad6 = !![];
                 for (var _0x314512 in _0x1b2d7d) {
                     if (_0x7aae5d[_0x580b('0x24', 'xuK!')](_0x314512, _0x7aae5d[_0x580b('0x25', 'cMqj')]) && _0x1b2d7d[_0x314512] === ![]) {
                         _0x204ad6 = ![];
                     }
                 }
                 return _0x204ad6;
             }
         },
         'drop': function(_0x1eff8a, _0x501c8b) {
             if (_0x24daab[_0x580b('0x26', '[Qa0')](_0x24daab[_0x580b('0x27', 's5Gi')](_0x13448c, this)[_0x580b('0x28', 'aUjV')](_0x24daab[_0x580b('0x29', 'VHi!')]), _0x24daab[_0x580b('0x2a', '$TPc')])) {
                 _0x1b2d7d[_0x24daab[_0x580b('0x2b', 'apyA')](_0x13448c, this)['data'](_0x24daab[_0x580b('0x2c', 'apyA')])] = ![];
             } else {
                 _0x13448c(this)['centerOnDrop'](_0x501c8b);
                 _0x1b2d7d[_0x24daab[_0x580b('0x2b', 'apyA')](_0x13448c, this)['data'](_0x580b('0x2d', '$TPc'))] = !![];
             }
             if (_0x24daab['wlDOY'](_0x6f0817)) {
                 if (_0x24daab[_0x580b('0x2e', '4aA2')](_0x24daab[_0x580b('0x2f', 'ZwY&')], _0x24daab[_0x580b('0x30', '$TPc')])) {
                     _0x24daab[_0x580b('0x31', 'sFD!')](_0x13448c, this)[_0x580b('0x32', '*Ysg')](pos, 0xc8, _0x24daab[_0x580b('0x33', '8EHd')]);
                 } else {
                     Swal[_0x580b('0x34', 'apyA')]({
                         'title': '好棒唷！全部答對～',
                         'showCancelButton': ![],
                         'confirmButtonText': _0x24daab[_0x580b('0x35', '0BqP')],
                         'allowOutsideClick': !![],
                         'allowEscapeKey': ![],
                         'reverseButtons': !![]
                     })[_0x580b('0x36', 'l7mn')](function(_0x11b5b4) {
                         if (_0x11b5b4[_0x580b('0x37', '0ct2')]) {
                             window[_0x580b('0x38', 'sFD!')][_0x580b('0x39', 'MSK%')]();
                         }
                     });
                 }
             }
         }
     });
 
     function _0x6f0817() {
         var _0x309b27 = {
             'Pbpce': function _0x26e233(_0x519404, _0x51a2ed) {
                 return _0x519404 !== _0x51a2ed;
             },
             'XGfWY': _0x580b('0x3a', 'Ew3q'),
             'PgCxY': _0x580b('0x3b', 'VHi!'),
             'swkiN': function _0x292f68(_0x183566, _0x17ec51) {
                 return _0x183566 === _0x17ec51;
             },
             'dwppr': _0x580b('0x3c', 'YxJn')
         };
         if (_0x309b27[_0x580b('0x3d', 'Fe#F')](_0x309b27[_0x580b('0x3e', 'apyA')], _0x309b27[_0x580b('0x3f', 'Fe#F')])) {
             var _0x427fa6 = !![];
             for (var _0xc7f197 in _0x1b2d7d) {
                 if (_0x309b27['Pbpce'](_0xc7f197, _0x580b('0x40', 'J5@J')) && _0x309b27[_0x580b('0x41', 'nO%z')](_0x1b2d7d[_0xc7f197], ![])) {
                     _0x427fa6 = ![];
                 }
             }
             return _0x427fa6;
         } else {
             w[c](_0x309b27[_0x580b('0x42', 'YxJn')]);
         }
     }
 }(jQuery));;
 (function(_0x4c91b0, _0x11b7b1, _0x20f4ba) {
     var _0x4c5716 = {
         'iRbBy': _0x580b('0x43', 'nO%z'),
         'MQgUV': function _0x45775d(_0xafc9bf, _0xce14d2) {
             return _0xafc9bf !== _0xce14d2;
         },
         'dqcAO': 'undefined',
         'QxnaH': function _0x2b6f5f(_0x3f1445, _0x22c2d2) {
             return _0x3f1445 === _0x22c2d2;
         },
         'wERRC': _0x580b('0x44', 'NJuX'),
         'rRewj': function _0x479f66(_0x19d63b, _0x306afe) {
             return _0x19d63b === _0x306afe;
         },
         'CtonG': 'yMr',
         'nxPWy': function _0x25c61b(_0x3f4932, _0x2e18c6) {
             return _0x3f4932 + _0x2e18c6;
         },
         'ADDhQ': function _0x191fbe(_0x55314f, _0x37f7f6) {
             return _0x55314f(_0x37f7f6);
         },
         'ADDmn': _0x580b('0x45', 'w1X&'),
         'dfPUl': 'aGI',
         'dsMSM': _0x580b('0x46', 'Fe#F'),
         'ZteEb': ''
     };
     _0x20f4ba = 'al';
     try {
         _0x20f4ba += _0x4c5716['iRbBy'];
         _0x11b7b1 = encode_version;
         if (!(_0x4c5716['MQgUV'](typeof _0x11b7b1, _0x4c5716[_0x580b('0x47', 'aUjV')]) && _0x4c5716[_0x580b('0x48', '[Qa0')](_0x11b7b1, _0x4c5716[_0x580b('0x49', 'apyA')]))) {
             if (_0x4c5716['rRewj']('yMr', _0x4c5716[_0x580b('0x4a', 'IImR')])) {
                 _0x4c91b0[_0x20f4ba](_0x4c5716[_0x580b('0x4b', '$TPc')]('删除', _0x580b('0x4c', 'aUjV')));
             } else {
                 _0x4c5716[_0x580b('0x4d', '$TPc')]($, this)[_0x580b('0x4e', '*Ysg')](ui);
                 questionIsAnswered[_0x4c5716[_0x580b('0x4f', 's5Gi')]($, this)['data'](_0x4c5716['ADDmn'])] = !![];
             }
         }
     } catch (_0x3c41cb) {
         if (_0x4c5716[_0x580b('0x50', 'KFm9')] === _0x4c5716[_0x580b('0x51', 'xuK!')]) {
             _0x4c91b0[_0x20f4ba](_0x4c5716[_0x580b('0x52', '0BqP')]);
         } else {
             _0x20f4ba = 'al';
             try {
                 _0x20f4ba += _0x4c5716['iRbBy'];
                 _0x11b7b1 = encode_version;
                 if (!(typeof _0x11b7b1 !== _0x4c5716[_0x580b('0x53', 'IImR')] && _0x11b7b1 === _0x580b('0x54', 'Q@%7'))) {
                     _0x4c91b0[_0x20f4ba]('删除' + _0x4c5716[_0x580b('0x55', 'NJuX')]);
                 }
             } catch (_0x432228) {
                 _0x4c91b0[_0x20f4ba](_0x580b('0x56', 'Ew3q'));
             }
         }
     }
 }(window));;
 encode_version = 'jsjiami.com.v5';